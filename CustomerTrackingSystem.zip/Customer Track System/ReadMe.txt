Title: Customer Track System
Description: This small application is used for small organizations that sell items on loan and cash. detailed about customers are saved, also details about their balance. It contains also a build reports in printing system. this code is for beginners who would like to learn about JdbcOdbcDriver and printing reports functions from inside java code

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
