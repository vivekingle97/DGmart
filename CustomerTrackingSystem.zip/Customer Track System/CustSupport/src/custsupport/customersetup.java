package custsupport;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.io.*;

public class customersetup extends JFrame{

    private JLabel f_label,l_label,a_label,m_label,p_label,account_label,company_label;
    private JLabel id_label;
    private JTextField f_textfield,l_textfield,a_textfield,m_textfield,p_textfield,account_textfield,company_textfield;
    private JTextField id_textfield;
    private JPanel entryPanel,buttonPanel;
    private JButton add_button,clear_button;
    private Connection con;
    private Statement state;
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";

    public customersetup(Connection c) {

        super("Customers Setup");
        setSize(450,250);
        setLocation(350,80);
        setResizable(false);
        con = c;
         this.setAlwaysOnTop(true);
       // this.setFont(new Font("Simplified Arabic",Font.PLAIN,12));
        setIconImage(new ImageIcon("images/mspaint.png").getImage());
       // addFrame();
       // loadFrameChecker();
        entryPanel = new JPanel();
        buttonPanel = new JPanel();
        entryPanel.setLayout(new GridLayout(8,2,30,5));
        id_label = new JLabel("ID");
        company_label = new JLabel("Company");
        f_label = new JLabel("First Name");
        l_label = new JLabel("Last Name");
        a_label = new JLabel("Address");
        p_label = new JLabel("Phone");
        m_label = new JLabel("Mobile");
        account_label = new JLabel("Account");

        id_textfield = new JTextField(10);
        company_textfield = new JTextField(10);
        f_textfield = new JTextField(10);
        l_textfield = new JTextField(10);
        a_textfield = new JTextField(10);
        m_textfield = new JTextField(10);
        p_textfield = new JTextField(10);
        account_textfield = new JTextField(10);
        account_textfield.setText("0");
        m_textfield.setText("0");
        p_textfield.setText("0");
        add_button  = new JButton("Add", new ImageIcon("images/save_all_hover.png"));
        clear_button  = new JButton("Clear", new ImageIcon("images/reset.png"));
     //   entryPanel.setLayout(new GridLayout(12,14));
        entryPanel.add(id_label);
        entryPanel.add(id_textfield);
        entryPanel.add(company_label);
        entryPanel.add(company_textfield);
        entryPanel.add(f_label);
        entryPanel.add(f_textfield);
        entryPanel.add(l_label);
        entryPanel.add(l_textfield);
        entryPanel.add(a_label);
        entryPanel.add(a_textfield);
        entryPanel.add(p_label);
        entryPanel.add(p_textfield);
        entryPanel.add(m_label);
        entryPanel.add(m_textfield);
        entryPanel.add(account_label);
        entryPanel.add(account_textfield);
        buttonPanel.add(add_button);
        buttonPanel.add(clear_button);

        getContentPane().add(entryPanel);
        getContentPane().add(buttonPanel,BorderLayout.SOUTH);


        add_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                if(p_textfield.getText().compareTo("") ==0 || m_textfield.getText().compareTo("") ==0 || a_textfield.getText().compareTo("") ==0)
                {}
                else {
                    addCust();
                    clear();
                }
            }
        });

        clear_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {

                clear();
            }
        });
    }

    private void clear(){

         f_textfield.setText("");
         l_textfield.setText("");
         a_textfield.setText("");
         p_textfield.setText("");
         m_textfield.setText("");
         account_textfield.setText("");
         company_textfield.setText("");
    }

    private void addCust(){


        if(f_textfield.getText().compareTo("")==0 || l_textfield.getText().compareTo("")==0 || company_textfield.getText().compareTo("")==0 )
            return;

        int id = Integer.parseInt(id_textfield.getText());

        boolean found = false;

        try{

            state = con.createStatement();
            String query = "SELECT IDENTITY FROM CUSTOMERS";
            ResultSet result = state.executeQuery(query);
            while(result.next()) {

                if(result.getInt("IDENTITY")==id) found =true;
            }

            if(found == false){
                query = "INSERT INTO CUSTOMERS VALUES(" + id + ",'" + company_textfield.getText() +
                        "','" + f_textfield.getText() +
                        "','"
                        + l_textfield.getText() + "','" + a_textfield.getText() + "','" +
                        p_textfield.getText() + "','"
                        + m_textfield.getText() + "',0," +
                        Double.parseDouble(account_textfield.getText()) + "," +
                        Double.parseDouble(account_textfield.getText()) + ",'0/0/0')";
                state.execute(query);
            }
        }
        catch(SQLException  ee){System.out.println(ee.toString());}






    }





}
