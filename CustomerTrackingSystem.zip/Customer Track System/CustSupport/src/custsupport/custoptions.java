package custsupport;

import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;

public class custoptions extends JFrame{

    private JLabel id_label;
    private JTextField input_textfield;
    private JButton edit_button,del_button;
//    private JPanel entryPanel,buttonPanel;
    private Connection con;
    private Statement state;
    private int id = -1;
    private JPanel entryPanel, buttonPanel;

      private String sMSGBOX_TITLE = "PayTrack System V. 1.0";



    public custoptions(Connection c) {

        super("Customer Options");
        setSize(300,200);
       setLocation(400,0);
       setResizable(false);
       this.setAlwaysOnTop(true);
       con = c;
       entryPanel = new JPanel();
//       editPanel = new JPanel();
       buttonPanel = new JPanel();

       id_label = new JLabel("ID");

       input_textfield = new JTextField(15);
       edit_button = new JButton("Edit", new ImageIcon("images/search.png"));
       del_button = new JButton("Delete", new ImageIcon("images/search.png"));
       entryPanel.add(id_label);
       entryPanel.add(input_textfield);
       buttonPanel.add(edit_button);
       buttonPanel.add(del_button);

       getContentPane().add(entryPanel,BorderLayout.NORTH);
       getContentPane().add(buttonPanel,BorderLayout.CENTER);

       del_button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {

       loadDeleting();

      }
  });

       edit_button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {

      custedit cedit = new custedit(con, Integer.parseInt(input_textfield.getText()));
      cedit.setVisible(true);
      }
  });


    }

    protected void loadDeleting()
{
try
   {
        if (input_textfield.getText().compareTo("") !=0){
            int reply = JOptionPane.showConfirmDialog(this,
                    "Are you sure to Delete customer account " + input_textfield.getText() + " ?",
                    sMSGBOX_TITLE, JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
            if (reply == JOptionPane.YES_OPTION) {

               // int id = findID();
               // getName(id);
                deletecust delete = new deletecust(con, Integer.parseInt(input_textfield.getText()));
                if (delete.deleteCust() == 1) input_textfield.setText(input_textfield.getText() + " deleted...");
                else input_textfield.setText("Not Found");

            }
        }
   }
        catch(Exception e)
        {}

}


}
