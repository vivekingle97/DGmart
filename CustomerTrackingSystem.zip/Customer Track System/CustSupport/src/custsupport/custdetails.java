package custsupport;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.text.SimpleDateFormat;
import java.io.*;

public class custdetails extends JFrame {

    private JScrollPane custoPanel;
    final  String columnNames[] = { "IDENTITY","COMPANY","CODE","DATE","AMOUNT"} ;
    private String pData[][];
    private JTable table;
    private Connection con;
    private Statement state;
    private int id=0;
    private String first_name ="";
    private String last_name ="";
    private JButton print_button;//,go_button,return_button;
    private JPanel printPanel;
   // private double unpaid = 0,paid =0,account=0;
   // private JLabel service_label,order_label;
   // private JTextField service_textfield,order_textfield;
   // private JTextArea output;
   // private String servicesn="";
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";
     private JTextField returnTextField;
     private int samount =0;
   //  private int select = 0;
   private String companyss = "";
    private double famount = 0;
        double fpriceamount = 0;
       // private JLabel priceandamount;


    public custdetails(Connection connection,String firstname,String lastname,int identity) {
        super(firstname + " " + lastname+" Information");
        setSize(900,700);
        setLocation(180,30);
        setResizable(false);
        con = connection;
        id = identity;
        first_name = firstname;
        last_name = lastname;
        setIconImage(new ImageIcon("images/LogDetails.png").getImage());
      //  addFrame();
       // loadFrameChecker();
        //buttonPanel = new JPanel();
        printPanel = new JPanel();
   //     collectStatus();
        collectData();
        table = new JTable(pData, columnNames );
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        custoPanel = new JScrollPane(table,v,h);
     //   remove_button = new JButton("Remove");
        print_button = new JButton("Print");
        //priceandamount = new JLabel("Amount & Price");
       // buttonPanel.add(add_button);
        //buttonPanel.add(remove_button);
        //buttonPanel.add(print_button);
     //   servicePanel.add(service_label);
      //  servicePanel.add(service_textfield);
       // servicePanel.add(go_button);
       // servicePanel.add(add_button);
        //servicePanel.add(print_button);
        //viewPanel.add(output);
        //addMouseListener(this);

       // goPanel.add(order_label);
       // goPanel.add(order_textfield);
       // goPanel.add(priceandamount);
       // goPanel.add(returnTextField);
       // goPanel.add(return_button);
       // bothPanel.add(servicePanel,BorderLayout.NORTH);
       // bothPanel.add(goPanel,BorderLayout.SOUTH);
       // getContentPane().add(bothPanel,BorderLayout.NORTH);
//        getContentPane().add(goPanel,BorderLayout.CENTER);
       printPanel.add(print_button);
        getContentPane().add(custoPanel,BorderLayout.CENTER);
        getContentPane().add(printPanel,BorderLayout.SOUTH);
       // getContentPane().add(new JScrollPane(output),BorderLayout.SOUTH);






        print_button.addActionListener(new ActionListener() {
                 public void actionPerformed(ActionEvent e)
                 {

                     table.setAlignmentX(0);
                     table.setAlignmentY(0);
                     table.setGridColor(Color.black);
//                table.setBorder(new AbstractAction());
                     table.setAutoResizeMode(1);
                     table.setShowGrid(true);
                     table.setShowHorizontalLines(true);
                     table.setShowVerticalLines(true);
                     printchecks pcheks = new printchecks(3,first_name+" "+last_name,table,"","","");
                     pcheks.print();



                 }
             });




        //addMenu();
    }


    private void collectData(){

       // int row = getRecNum();
        int i =0;
        //        int row = 0;
        setLength();

         try{

             state = con.createStatement();

             String query = "SELECT IDENTITY, COMPANY, CODE , DATE, AMOUNT FROM CUSTDETAILS WHERE IDENTITY = "+id+"";
             ResultSet result = state.executeQuery(query);
//             final  String columnNames[] = { "TYPE","COMPANY","BUY DATE","AMOUNT","UNIT PRICE","TOTAL PRICE"} ;
             while (result.next()){

                 pData[i][0] = Integer.toString(result.getInt("IDENTITY"));
                 pData[i][1] = result.getString("COMPANY");
                 pData[i][2] = result.getString("CODE");
                 pData[i][3] = result.getString("DATE");
             //    pData[i][3] = Integer.toString(result.getInt("SERVICE"));
                 pData[i][4] = Double.toString(result.getDouble("AMOUNT"));

                i++;

             }



         }
         catch(SQLException  ee){System.out.println(ee.toString());}


    }

    private void setLength(){

        int row = 0;
        try{

            state = con.createStatement();

            String query = "SELECT * FROM CUSTDETAILS WHERE IDENTITY = "+id+"";
            ResultSet result1 = state.executeQuery(query);
            while(result1.next()) row++;
//            row = result1.getInt("CUSTODETAILS");

            pData = new String[row] [5];





        }
        catch(SQLException  ee){System.out.println(ee.toString());}



    }





    private void showAdd(){
        collectData();
        getContentPane().removeAll();
        table = new JTable(pData, columnNames );
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        custoPanel = new JScrollPane(table,v,h);
       // print_button.setVisible(false);
    ;
     getContentPane().add(custoPanel,BorderLayout.CENTER);
    // getContentPane().add(new JScrollPane(output),BorderLayout.SOUTH);

        show();
    }



}
