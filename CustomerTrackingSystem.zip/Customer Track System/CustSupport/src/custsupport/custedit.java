package custsupport;

import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.text.SimpleDateFormat;
import java.io.*;

public class custedit extends JFrame{

    private JTextField fname_textfield,lname_textfield,phone_textfield,mobile_textfield,address_textfield,id_textfield;
   private JLabel fname_label,lname_label,phone_label,mobile_label,address_label,id_label;
   private JButton save_button,clear_button;
   private JPanel entryPanel,buttonPanel;

   private Connection con;
   private Statement state;

   private int id = -1 ;
   private    String sMSGBOX_TITLE	= "Customer Support V. 1.0";



    public custedit(Connection c,int ident) {

        super("Editing " + ident);
        setSize(350,270);
        setLocation(350,80);
        setResizable(false);
         this.setAlwaysOnTop(true);
        setIconImage(new ImageIcon("images/edit.png").getImage());

        con = c;
        id = ident;
        entryPanel = new JPanel();
        entryPanel.setLayout(new GridLayout(8,2,30,5));
        buttonPanel = new JPanel();
        fname_label = new JLabel("First Name");
        fname_textfield = new JTextField(10);

        lname_label = new JLabel("Last Name");
        lname_textfield = new JTextField(10);

        phone_label = new JLabel("Phone");
        phone_textfield = new JTextField(10);
        mobile_label = new JLabel("Mobile");
        mobile_textfield = new JTextField(10);
        address_label = new JLabel("Address");
        address_textfield = new JTextField(10);
        id_label = new JLabel("ID");
        id_textfield = new JTextField(10);

        id_textfield.setEditable(false);
        save_button =  new JButton("Update", new ImageIcon("images/save_all_hover.png"));
        clear_button = new JButton("Reset", new ImageIcon("images/reset.png"));
        entryPanel.add(id_label);
        entryPanel.add(id_textfield);
        entryPanel.add(fname_label);
        entryPanel.add(fname_textfield);

        entryPanel.add(lname_label);
        entryPanel.add(lname_textfield);
        entryPanel.add(address_label);
        entryPanel.add(address_textfield);

        entryPanel.add(phone_label);
        entryPanel.add(phone_textfield);
        entryPanel.add(mobile_label);
        entryPanel.add(mobile_textfield);


        buttonPanel.add(save_button);
        buttonPanel.add(clear_button);
        getContentPane().add(entryPanel,BorderLayout.NORTH);
        getContentPane().add(buttonPanel);

        collectData();
        clear_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {

                collectData();
            }
        });
        save_button.addActionListener(new ActionListener() {
             public void actionPerformed(ActionEvent e)
             {
                 sureTo();
             }
        });
    }

    protected void sureTo()
{
    try
    {
        int reply = JOptionPane.showConfirmDialog(this,"Are you sure to update ?",sMSGBOX_TITLE,JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            if (reply == JOptionPane.YES_OPTION)
            {
                update();
            }
        }
        catch(Exception e)
        {System.out.println(e.toString());}

}// Close the Windows


    private void update(){



    try {

         state = con.createStatement();

         String query = "UPDATE CUSTOMERS SET FNAME = '"+fname_textfield.getText()+"' , LNAME = '"+lname_textfield.getText()
                        +"' ,  PHONE = '"+phone_textfield.getText()+"' , MOBILE = '"+mobile_textfield.getText()
                        +"' ,  ADDRESS = '"+address_textfield.getText()+"'  WHERE IDENTITY = "
                        +id+" ";
         System.out.println(query);
         state.executeUpdate(query);

     } catch (SQLException ee) {
         System.out.println(ee.getLocalizedMessage()+ " in update()");
     }
}

 private void collectData(){
    try {


        state = con.createStatement();

        String query = "SELECT * FROM CUSTOMERS WHERE IDENTITY = " +
                       id + " ";
        ResultSet result = state.executeQuery(query);
       // for (int i = 0; i < num; i++)  result.next();
      if( result.next()){
          id = result.getInt("IDENTITY");
          fname_textfield.setText(result.getString("FNAME"));
          lname_textfield.setText(result.getString("LNAME"));
          address_textfield.setText(result.getString("ADDRESS"));
          phone_textfield.setText(result.getString("PHONE")+"");
          mobile_textfield.setText(result.getString("MOBILE")+"");
          id_textfield.setText(id+"");
      }


    } catch (SQLException ee) {
        System.out.println(ee.toString());
    }
}


}
