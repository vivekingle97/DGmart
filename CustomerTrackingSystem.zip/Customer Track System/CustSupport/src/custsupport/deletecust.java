package custsupport;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class deletecust extends JFrame{

    private Connection con;
    private Statement state;
    private JButton yes_button,no_button;
    private JLabel label;
    private int id=0;
    private JPanel entryPanel,buttonPanel;
    private JLabel fill1,fill2,fill3,fill4;
//    private custdetails details;


    public deletecust(Connection connection,int identity) {
        super("Deleting "+identity);
       setSize(400,120);
       setLocation(350,80);
       setResizable(false);
        this.setAlwaysOnTop(true);
       con = connection;
       id = identity;
       //details = cust;
       setIconImage(new ImageIcon("images/delete_Hover.png").getImage());
       entryPanel = new JPanel();
       buttonPanel = new JPanel();
       fill1 = new JLabel();
       fill2 = new JLabel();
       fill3 = new JLabel();
       fill4 = new JLabel();
       buttonPanel.setLayout(new GridLayout(1,2,10,10));
       label = new JLabel("Are you sure you want to delete "+identity +" ?");
       yes_button = new JButton("Yes");
       no_button = new JButton("No");
       entryPanel.add(label);
       buttonPanel.add(fill1);
       buttonPanel.add(yes_button);
       buttonPanel.add(fill2);
       buttonPanel.add(fill3);
       buttonPanel.add(no_button);
       buttonPanel.add(fill4);

       getContentPane().add(entryPanel);
       getContentPane().add(buttonPanel,BorderLayout.SOUTH);


       yes_button.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e)
                   {
                       deleteCust();
                      // details.setVisible(false);
                       setVisible(false);
                   }
               });

       no_button.addActionListener(new ActionListener() {
                          public void actionPerformed(ActionEvent e)
                          {
                              setVisible(false);
                          }
               });

    }

    public int deleteCust(){

        try{

            state = con.createStatement();

            String query = "SELECT * FROM CUSTOMERS WHERE IDENTITY ="+id+"";
            ResultSet result = state.executeQuery(query);
            if(result.next()) {
                state.execute("INSERT INTO DELETECUSTOMERS VALUES(" +
                              result.getInt("IDENTITY") + ",'" +
                              result.getString("FNAME") + "','" +
                              result.getString("LNAME")
                              + "','" + result.getString("ADDRESS") + "','" +
                              result.getString("PHONE") + "','" +
                              result.getString("MOBILE") + "'," +
                              result.getDouble("PAIED")
                              + "," + result.getDouble("UNPAIED")
                              + "," + result.getDouble("ACCOUNT") + ")");

                query = "DELETE FROM CUSTOMERS WHERE IDENTITY = " + id + "";
                state.executeUpdate(query);
                query = "DELETE FROM CUSTDETAILS WHERE IDENTITY = " + id + "";
                state.executeUpdate(query);
                query = "DELETE FROM CUSTPAYMENT WHERE ID = " + id + "";
                state.executeUpdate(query);
                return 1;
            }




        }
        catch(SQLException  ee){System.out.println(ee.toString()); return 0;}

        return 0;
    }

}
