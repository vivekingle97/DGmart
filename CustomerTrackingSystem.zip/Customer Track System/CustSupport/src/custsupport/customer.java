package custsupport;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.io.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class customer extends JFrame{

    private JLabel f_label,l_label,a_label,m_label,p_label,account_label,paid_label,unpaid_label,id_label,count_label;
    private JTextField f_textfield,l_textfield,a_textfield,m_textfield,p_textfield,
    account_textfield,paid_textfield,unpaid_textfield,identity_textfield,count_textfield;
    private JTextField search_lname,search_fname;
    private JLabel search_lname_label,search_id_label,search_fname_label;
    private JButton get_button,clear_button;//,del_button;
    private JButton pay_button, sell_button,show_button;
    private JTextField id_textfield;
    private JPanel entryPanel,buttonPanel,button1Panel;
    private JScrollPane custoPanel;
    final  String columnNames[] = { "ID","Company","FirstName","LastName","Address"} ;
    private String pData[][];
    private JTable table;
    private Container contentPane;
    private Connection con;
    private Statement state;
    private String fname ="";
    private String lname ="";
//    private clsSettings settings;
    private JPanel panel_Top;
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";
   // private int id = -1;
   private JLabel fill1button1,fill2button1,fill3button1,fill4button1;
   private String company ="";


    public customer() {

        super("Customers Support Center");
        setSize(1100,650);
        setLocation(70,80);
        setResizable(false);
        initialize init = new initialize();

        con = init.connect();

       // setIconImage(new ImageIcon("images/emp_rpt.png").getImage());
      //  addFrame();
       // loadFrameChecker();
       // settings 	= new clsSettings();
        entryPanel = new JPanel();
        buttonPanel = new JPanel();
        button1Panel = new JPanel();
      //  button1Panel.setLayout(new GridLayout(2,4));
        button1Panel.setPreferredSize(new Dimension(200,40));

        panel_Top = new JPanel();
        panel_Top.setLayout(new BorderLayout());
        panel_Top.setPreferredSize(new Dimension(10,65));
        //panel_Top.add(createJToolBar(),BorderLayout.PAGE_START);

        contentPane = getContentPane();

        contentPane.setLayout(new BorderLayout());
        collectData();
        fill1button1 = new JLabel();
        fill2button1 = new JLabel();
        fill3button1 = new JLabel();
        fill4button1 = new JLabel();

         table = new JTable(pData, columnNames );
         int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
         int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        custoPanel = new JScrollPane(table,v,h);

        search_lname = new JTextField(10);
        search_fname = new JTextField(10);
        search_lname_label = new JLabel("Last Name");
        search_fname_label = new JLabel("First Name");
        search_id_label = new JLabel("ID              ");

        f_label = new JLabel("First Name");
        l_label = new JLabel("Last Name");
        a_label = new JLabel("Address");
        p_label = new JLabel("Phone");
        m_label = new JLabel("Mobile");
        account_label = new JLabel("Account");
        unpaid_label = new JLabel("Unpaid");
        paid_label = new JLabel("Paid");
        id_label = new JLabel("ID");
        count_label = new JLabel("Records");

        f_textfield = new JTextField(10);
        f_textfield.setEditable(false);
        f_textfield.setBackground(Color.white);
        l_textfield = new JTextField(10);
        l_textfield.setEditable(false);
        l_textfield.setBackground(Color.white);
        a_textfield = new JTextField(10);
        a_textfield.setEditable(false);
        a_textfield.setBackground(Color.white);
        m_textfield = new JTextField(10);
        m_textfield.setEditable(false);
        m_textfield.setBackground(Color.white);
        p_textfield = new JTextField(10);
        p_textfield.setEditable(false);
        p_textfield.setBackground(Color.white);
        account_textfield = new JTextField(10);
        account_textfield.setEditable(false);
        account_textfield.setBackground(Color.white);
        paid_textfield = new JTextField(10);
        paid_textfield.setEditable(false);
        paid_textfield.setBackground(Color.white);
        unpaid_textfield = new JTextField(10);
        unpaid_textfield.setEditable(false);
        unpaid_textfield.setBackground(Color.white);
        identity_textfield = new JTextField(10);
        identity_textfield.setEditable(false);
        identity_textfield.setBackground(Color.white);
        count_textfield = new JTextField(5);
        count_textfield.setText(Integer.toString(table.getRowCount()));

        get_button = new JButton("Get", new ImageIcon("images/search.png"));
        clear_button = new JButton("clear", new ImageIcon("images/reset.png"));
        id_textfield = new JTextField(10);
        pay_button = new JButton("Pay", new ImageIcon("images/payments.png"));
        sell_button = new JButton("Sell");
        show_button = new JButton("Show", new ImageIcon("images/reload_Hover.png"));
        //del_button = new JButton("Delete", new ImageIcon("images/delete.png"));


        entryPanel.setLayout(new GridLayout(3,4,30,30));
        entryPanel.add(f_label);
        entryPanel.add(f_textfield);
        entryPanel.add(l_label);
        entryPanel.add(l_textfield);
        entryPanel.add(a_label);
        entryPanel.add(a_textfield);
        entryPanel.add(p_label);
        entryPanel.add(p_textfield);
        entryPanel.add(m_label);
        entryPanel.add(m_textfield);
        entryPanel.add(account_label);
        entryPanel.add(account_textfield);
        entryPanel.add(unpaid_label);
        entryPanel.add(unpaid_textfield);
        entryPanel.add(paid_label);
        entryPanel.add(paid_textfield);
        entryPanel.add(id_label);
        entryPanel.add(identity_textfield);

       // custoPanel.add(table);
       buttonPanel.add(count_label);
       buttonPanel.add(count_textfield);
       buttonPanel.add(pay_button);
       buttonPanel.add(sell_button);
//       buttonPanel.add(del_button);
       buttonPanel.add(show_button);
       buttonPanel.add(clear_button);

       button1Panel.add(fill1button1);

      button1Panel.add(search_id_label);
       button1Panel.add(fill2button1);
       button1Panel.add(id_textfield);
       button1Panel.add(fill3button1);
       button1Panel.add(search_lname_label);
       button1Panel.add(fill4button1);
       button1Panel.add(search_lname);
       button1Panel.add(search_fname_label);
      button1Panel.add(fill4button1);
      button1Panel.add(search_fname);

       button1Panel.add(get_button);



       //contentPane.add(panel_Top,BorderLayout.PAGE_START);
       contentPane.add(entryPanel,BorderLayout.NORTH);
        contentPane.add(button1Panel,BorderLayout.AFTER_LINE_ENDS);
        contentPane.add(custoPanel);
        contentPane.add(buttonPanel,BorderLayout.SOUTH);
        addMenu();

        sell_button.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent e)
              {
                  if (f_textfield.getText().compareTo("") !=0){
                      int rec = findID();
                      getName(rec);
                    sellcust custosell = new sellcust (con, rec, fname+ lname,company);

                      custosell.setVisible(true);

                  }
              }
          });




        pay_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {

                if (f_textfield.getText().compareTo("") !=0){
                    paycust paycustomer = new paycust(lname,fname,Integer.parseInt(identity_textfield.getText()),con);
                    paycustomer.setVisible(true);
                    clear();

            }
        }
        });
        clear_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                clear();

            }
        });

        get_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                if(search_lname.getText().compareTo("")!=0 || search_fname.getText().compareTo("")!=0  ){
                    findCustomer();
                    getContentPane().removeAll();
                    table = new JTable(pData, columnNames );
                    int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
                    int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
                    custoPanel = new JScrollPane(table,v,h);
                    contentPane.add(entryPanel,BorderLayout.NORTH);
                    contentPane.add(button1Panel,BorderLayout.AFTER_LINE_ENDS);
                    contentPane.add(custoPanel);
                    contentPane.add(buttonPanel,BorderLayout.SOUTH);
                    count_textfield.setText(Integer.toString(table.getRowCount()));
                    show();
                    get_button.setEnabled(false);
                    search_lname.setText("Press Show");
                    search_fname.setText("Press Show");
                }
                else
                getcust(findID());
            }
        });
        show_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                get_button.setEnabled(true);
                collectData();
                getContentPane().removeAll();
                table = new JTable(pData, columnNames );
                int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
                int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
                custoPanel = new JScrollPane(table,v,h);
                contentPane.add(entryPanel,BorderLayout.NORTH);
                contentPane.add(button1Panel,BorderLayout.AFTER_LINE_ENDS);
                contentPane.add(custoPanel);
                contentPane.add(buttonPanel,BorderLayout.SOUTH);
                count_textfield.setText(Integer.toString(table.getRowCount()));
                search_lname.setText("");
                search_fname.setText("");
                show();
            }
        });

        addWindowListener(new WindowAdapter(){

            public void windowClosing(WindowEvent e)
            {
                UnloadWindow();
            }
        });


    }



    private void collectData(){

        int row = getRecNum();
        int i =0;
         pData = new String[row] [5];
         //System.out.println(new SimpleDateFormat().format(new Date()));
        // System.out.println(new SimpleDateFormat().YEAR_FIELD);
         try{

             state = con.createStatement();

             String query = "SELECT IDENTITY,COMPANY,LNAME,FNAME,ADDRESS FROM CUSTOMERS";
             ResultSet result = state.executeQuery(query);
             while (result.next()){

                 pData[i][0] = Integer.toString(result.getInt("IDENTITY"));
                 pData[i][1] = result.getString("COMPANY");
                 pData[i][2] = result.getString("FNAME");
                 pData[i][3] = result.getString("LNAME");
                 pData[i][4] = result.getString("ADDRESS");
                i++;

             }



         }
         catch(SQLException  ee){System.out.println(ee.toString());}


    }


    private int getRecNum(){
        int num = 0;
        try{

            state = con.createStatement();

            String query = "SELECT * FROM CUSTOMERS";
            ResultSet result = state.executeQuery(query);
            while (result.next()) num++;
        }
        catch(SQLException  ee){System.out.println(ee.toString() + "IN CUSTOMER CLASS METHOD GetRecNum");}




        return num;
    }

    private void addMenu() {
        JMenuBar mbar = new JMenuBar();
        JMenu menu = new JMenu("File");
        JMenuItem add_user = new JMenuItem("New");
        JMenu menu1 = new JMenu("View");
       // JMenu menu2 = new JMenu("Options");
        JMenuItem deleted_user = new JMenuItem("Recycle");
        JMenuItem pay_user = new JMenuItem("Payments");
        JMenuItem details_user = new JMenuItem("Details");
        JMenuItem checklist = new JMenuItem("CheckList");
        JMenuItem options_item = new JMenuItem("Options");
        JMenu menu2 = new JMenu("Software");
        JMenuItem softinfo = new JMenuItem("Info");
        JMenuItem newsoft = new JMenuItem("New");

        options_item.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e)
                   {
                       custoptions cop = new custoptions(con);
                       cop.setVisible(true);

                   }
        });

        add_user.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                customersetup cus = new customersetup(con);
                cus.setVisible(true);

            }
        });
        softinfo.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        softdesc sd = new softdesc(con);
                        sd.setVisible(true);

                    }
                });
        newsoft.addActionListener(new ActionListener() {
                      public void actionPerformed(ActionEvent e)
                      {
                          newsoft ns = new newsoft(con);
                          ns.setVisible(true);

                      }
                  });


       /* checklist.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e)
           {
              monthpayment mpay = new monthpayment(con);
               mpay.setVisible(true);

           }
       });*/


        details_user.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e)
                   {
                       if (f_textfield.getText().compareTo("") !=0){
                           custdetails cusd = new custdetails(con, lname, fname,
                                   Integer.parseInt(identity_textfield.getText()));
                           cusd.setVisible(true);
                       }
                   }
        });

        deleted_user.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                showdelcust show = new showdelcust(con);
                show.setVisible(true);


            }
        });

        pay_user.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                 if (f_textfield.getText().compareTo("") !=0){
                     custpayments payments = new custpayments(con,l_textfield.getText(), f_textfield.getText(),
                            Integer.parseInt(identity_textfield.getText()),paid_textfield.getText(),unpaid_textfield.getText(),account_textfield.getText());
                     payments.setVisible(true);
                 }
            }
        });


        menu.add(add_user);
      //  menu.add(checklist);
        menu.add(options_item);
        menu1.add(pay_user);
        menu1.add(details_user);
        menu1.add(deleted_user);
        menu2.add(newsoft);
        menu2.add(softinfo);

        mbar.add(menu);
        mbar.add(menu1);
        mbar.add(menu2);
        setJMenuBar(mbar);
    }

    private void clear(){

        f_textfield.setText("");
        l_textfield.setText("");
        a_textfield.setText("");
        p_textfield.setText("");
        m_textfield.setText("");
        account_textfield.setText("");
        paid_textfield.setText("");
        unpaid_textfield.setText("");
        identity_textfield.setText("");
        id_textfield.setText("");
        search_fname.setText("");
        search_lname.setText("");
    //    id = -1;
    }


    private void getcust(int identity){

        try{

            state = con.createStatement();

            String query = "SELECT * FROM CUSTOMERS WHERE IDENTITY = "+identity+"";
            ResultSet result = state.executeQuery(query);
           if( result.next()){
               fname = result.getString("FNAME");
               f_textfield.setText(fname);
               lname = result.getString("LNAME");
               l_textfield.setText(lname);
               company = result.getString("COMPANY");

               a_textfield.setText(result.getString("ADDRESS"));
               account_textfield.setText(Double.toString(result.getDouble(
                       "ACCOUNT")));
               paid_textfield.setText(Double.toString(result.getDouble("PAIED")));
               unpaid_textfield.setText(Double.toString(result.getDouble(
                       "UNPAIED")));
               p_textfield.setText(result.getString("PHONE"));
               m_textfield.setText(result.getString("MOBILE"));
               identity_textfield.setText(Integer.toString(result.getInt(
                       "IDENTITY")));
           }
           else clear();
        }
        catch(SQLException  ee){System.out.println(ee.toString());}


    }

    private int findID(){
        int rec = -1;
       // id = Integer.parseInt(id_textfield.getText());

        if(id_textfield.getText().compareTo("")!=0)
            rec = Integer.parseInt(id_textfield.getText());
        else{
            int record= table.getSelectedRow()+1;
            //System.out.println(record);
            //int stockid = -1;
            try{

                state = con.createStatement();

                String query =
                        "SELECT IDENTITY FROM CUSTOMERS";
                ResultSet result = state.executeQuery(query);

                for (int i = 0; i < record; i++) {
                    result.next();
                }
                rec = result.getInt("IDENTITY");
                id_textfield.setText(Integer.toString(rec));
                id_textfield.setText("");
            }
            catch(SQLException  ee){System.out.println(ee.toString());}

        }
System.out.println(rec);
        return rec;
    }

    private void getName(int iden){
        try{

            state = con.createStatement();

            String query =
                    "SELECT FNAME,LNAME,COMPANY FROM CUSTOMERS WHERE IDENTITY ="+iden+" ";
            ResultSet result = state.executeQuery(query);
            result.next();
            lname = result.getString("LNAME");
            fname = result.getString("FNAME");
            company = result.getString("COMPANY");
        }
        catch(SQLException  ee){System.out.println(ee.toString());}


    }


      private void findCustomer(){

          int i =0;
          int row=0;
          if(search_lname.getText().compareTo("")!=0){
              row = getRecordsNum(1,search_lname.getText().toLowerCase());
          }
          if(search_fname.getText().compareTo("")!=0) {
              row = getRecordsNum(2,search_fname.getText().toLowerCase());
          }

          pData = new String[row] [5];
          String query;
          try{

              state = con.createStatement();
              if(search_lname.getText().compareTo("")!=0){
                  query =
                          "SELECT IDENTITY,COMPANY,LNAME,FNAME,ADDRESS FROM CUSTOMERS WHERE LNAME LIKE '" +
                          search_lname.getText() + "%'";
//                   row = getRecordsNum(2,search_fname.getText().toLowerCase());
              }
              else {
                  query =
                          "SELECT IDENTITY,COMPANY,LNAME,FNAME,ADDRESS FROM CUSTOMERS WHERE FNAME LIKE '" +
                          search_fname.getText() + "%'";
  //                 row = getRecordsNum(1,search_lname.getText().toLowerCase());
              }

              ResultSet result = state.executeQuery(query);


              while(  result.next())
                {


                 pData[i][0] = Integer.toString(result.getInt("IDENTITY"));
                 pData[i][1] = result.getString("COMPANY");
                 pData[i][2] = result.getString("FNAME");
                 pData[i][3] = result.getString("LNAME");
                 pData[i][4] = result.getString("ADDRESS");
                i++;

             }


              }
          catch(SQLException  ee){System.out.println(ee.toString());}



      }
      private int getRecordsNum(int choice,String name){
          int num = 0;
          String query;
          try{

              state = con.createStatement();
              if(choice ==1)
//               query = "SELECT * FROM CUSTOMERS WHERE LNAME = '"+name+"'";   LIKE 'comp*';
                  query = "SELECT * FROM CUSTOMERS WHERE LNAME LIKE '"+name+"%'";
              else
//                  query = "SELECT * FROM CUSTOMERS WHERE FNAME = '"+name+"'";
                  query = "SELECT * FROM CUSTOMERS WHERE FNAME LIKE '"+name+"%'";

              ResultSet result = state.executeQuery(query);
              while (result.next()) num++;
          }
          catch(SQLException  ee){System.out.println(ee.toString());}




          return num;
    }
    protected void UnloadWindow()
{
try
   {
        int reply = JOptionPane.showConfirmDialog(this,"Are you sure to exit?",sMSGBOX_TITLE,JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);
                if (reply == JOptionPane.YES_OPTION)
                        {
                            con.close();
                            System.exit(0);
                        }
   }
        catch(Exception e)
        {}

}// Close the Windows

    public static void main(String[] args) {
         customer cust = new customer();
         cust.setVisible(true);
    }

}
