package custsupport;
import java.io.*;
import java.sql.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class initialize {

    private String maxframe = "4";
    public Connection con;
    private String DRIVER = "sun.jdbc.odbc.JdbcOdbcDriver";
    private String URL    =   "jdbc:odbc:CustomerSupport";





    public initialize() {

    }
    public Connection connect() {

        try {
            String adminDir         = "Database";
            String adminFileName    = "db";
            String adminPathName    = adminDir+File.separator+adminFileName;



            Class.forName(DRIVER);

            con = DriverManager.getConnection(URL,"admin","master");


        }
        catch(Exception ex) {
            System.out.println(ex.toString());
        }


        return con;


    }

    public void setup(){

        try{
            File file1 = new File("init.pop");
            PrintWriter pw1 = new PrintWriter(new FileWriter(file1, false));
            pw1.println("0");
            pw1.close();
        }
    catch (IOException exception) {
        System.out.println(exception.toString());
    }


    }


}
