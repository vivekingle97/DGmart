package custsupport;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.io.*;


public class newsoft extends JFrame{
    private JLabel code_label,name_label,startdate_label,enddate_label,amount_label,version_label;//,account_label,company_label;
   private JTextField code_textfield,name_textfield,startdate_textfield,enddate_textfield,version_textfield,amount_textfield;//,p_textfield,account_textfield,company_textfield;
   private JPanel entryPanel,buttonPanel;
   private JButton add_button,clear_button;
   private Connection con;
   private Statement state;
   private String sMSGBOX_TITLE = "Customer Support V. 1.0";

    public newsoft(Connection c) {

        super("New Software");
       setSize(300,250);
       setLocation(350,80);
       setResizable(false);
       con = c;
        this.setAlwaysOnTop(true);
        entryPanel = new JPanel();
        buttonPanel = new JPanel();
        entryPanel.setLayout(new GridLayout(6,2,30,5));
        code_label = new JLabel("Code");
       name_label = new JLabel("Name");
       version_label = new JLabel("Version");
       startdate_label = new JLabel("Stating Date");
       enddate_label = new JLabel("Ending Date");
       amount_label = new JLabel("Amount");

       code_textfield = new JTextField(10);
        name_textfield = new JTextField(10);
        version_textfield = new JTextField(10);
        startdate_textfield = new JTextField(10);
        enddate_textfield = new JTextField(10);
        amount_textfield = new JTextField(10);

        add_button  = new JButton("Add");
        clear_button  = new JButton("Clear");
        entryPanel.add(code_label);
        entryPanel.add(code_textfield);
        entryPanel.add(name_label);
        entryPanel.add(name_textfield);
        entryPanel.add(version_label);
        entryPanel.add(version_textfield);
        entryPanel.add(startdate_label);
        entryPanel.add(startdate_textfield);
        entryPanel.add(enddate_label);
        entryPanel.add(enddate_textfield);
        entryPanel.add(amount_label);
        entryPanel.add(amount_textfield);
        buttonPanel.add(add_button);
        buttonPanel.add(clear_button);

        getContentPane().add(entryPanel);
        getContentPane().add(buttonPanel,BorderLayout.SOUTH);


        add_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                if(version_textfield.getText().compareTo("") ==0 || code_textfield.getText().compareTo("") ==0 || name_textfield.getText().compareTo("") ==0 || startdate_textfield.getText().compareTo("") ==0 || amount_textfield.getText().compareTo("") ==0 || enddate_textfield.getText().compareTo("") ==0)
                {}
                else {
                    addCust();
                    clear();
                }
            }
        });

        clear_button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {

                clear();
            }
        });
    }

    private void clear(){

         code_textfield.setText("");
         name_textfield.setText("");
         amount_textfield.setText("");
         startdate_textfield.setText("");
         enddate_textfield.setText("");
         version_textfield.setText("");

    }
    private void addCust(){

        String query = "";
        try{
            state = con.createStatement();

                query = "INSERT INTO SOFTWARE VALUES('" + code_textfield.getText() + "','" + name_textfield.getText().toUpperCase() +
                        "'," +
                        Double.parseDouble(version_textfield.getText()) + ",'" + startdate_textfield.getText() +
                        "','"
                        + enddate_textfield.getText() + "',0," +
                        Double.parseDouble(amount_textfield.getText()) + ")";
                state.execute(query);

        }
        catch(SQLException  ee){System.out.println(ee.toString());}






    }

}
