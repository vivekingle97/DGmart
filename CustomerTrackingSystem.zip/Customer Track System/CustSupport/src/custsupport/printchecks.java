package custsupport;
import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class printchecks extends JFrame implements Printable{
    private Date date;
    private String input="";
    private JTable tableView;
    private JLabel label;
    private int choice = 0;
    private String paid ="",unpaid ="";
    private String account ="";

    public printchecks(int select,String in,JTable table,String p,String up,String acc) {

        paid = p;
        unpaid =up;
        account = acc;
        choice = select;
        date = new Date();
        label = new JLabel("HALIM KHOURY FOR TRADING");
        input = in;
        tableView = table;
//        table.setBackground(Color.white);

    }

    public void print(){


        //print_button.setVisible(false);
       // print_button.setVisible(false);

         PrinterJob printerJob = PrinterJob.getPrinterJob();

        // Get and change default page format settings if necessary.

        PageFormat pageFormat = printerJob.defaultPage();
      //  Paper paper = new Paper();
       // paper.setSize(297,210);

        //if(choice ==4)        pageFormat.setOrientation(PageFormat.LANDSCAPE);
        if(choice ==4)         pageFormat.setOrientation(PageFormat.LANDSCAPE);
        else pageFormat.setOrientation(PageFormat.PORTRAIT);
       // pageFormat.setPaper(paper);

        printerJob.setPrintable(printchecks.this);


        printerJob.setJobName("PayTrack System Printing");



        if (printerJob.printDialog()) {
            try {
                printerJob.print();

            } catch (Exception PrintException) {
                PrintException.printStackTrace();
            }

            printerJob.cancel();


        }

        printerJob.cancel();






    }
    public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {



        Graphics2D  g2 = (Graphics2D) g;
               g2.setColor(Color.black);
               //   g2.setColor(Color.red);
               g2.translate(pf.getImageableX(), pf.getImageableY());

               Font  f = new Font("Monospaced",Font.BOLD,12);
               g2.setFont (f);
               g2.drawString("COMPUTER SYSTEM",10,10);
               f = new Font("Monospaced",Font.PLAIN,12);
               g2.setFont (f);
               g2.drawString("AKKAR, HALBA Main road",10,25);
               g2.drawString("Tel: 06/691376",10,40);
               g2.drawString("Mobile: 03/426610",10,55);
               g2.drawLine(10,60,480,60);

               if(choice ==1){

                   g2.drawString("PAYMENTS DETAILS", 200, 55);
                   g2.drawString("Details about: ", 10, 110);
                   g2.setColor(Color.red);
                   g2.setFont(new Font("Monospaced",Font.BOLD,14));
                   g2.drawString(input, 150, 110);
                   g2.drawString("ACCOUNT: "+account+"$",310,10);
                   g2.drawString("PAID: "+paid+"$", 310, 25);

                   g2.drawString("UNPAID: "+unpaid+"$", 310, 40);
               }
               if(choice ==2){

                   g2.drawString(" CHECKS DETAILS", 200, 55);
                   g2.drawString("Printed Date: ", 10, 110);
                   g2.setColor(Color.red);
                   g2.setFont(new Font("Monospaced",Font.BOLD,14));
                   g2.drawString(date.toString(), 150, 110);

               }

               if(choice ==3){

                   g2.drawString("Satement Of Fees", 200, 55);
                   g2.drawString("Details about: ", 10, 110);
                   g2.setColor(Color.red);
                   g2.setFont(new Font("Monospaced",Font.BOLD,14));
                   g2.drawString(input, 150, 110);
                   g2.drawString("ACCOUNT: "+account+"$",310,10);
                   g2.drawString("PAID: "+paid+"$", 310, 25);

                   g2.drawString("UNPAID: "+unpaid+"$", 310, 40);

               }

               if(choice ==4){
               g2.setColor(Color.red);
                   g2.drawString(" YEARLY PAYMENTS", 200, 55);
                   g2.setFont(new Font("Monospaced", Font.ITALIC, 8));
                  g2.drawString("(Page: " + (pi+1)+")", 210, 90);
                  g2.setFont(f);

                   g2.drawString("Printed Date: ", 10, 110);
                   g2.setColor(Color.red);
                   g2.setFont(new Font("Monospaced",Font.BOLD,14));
                   g2.drawString(date.toString(), 150, 110);

               }

               paint(g2);

               g2.translate(-60,60);

//               g2.setColor(Color.black);
               int fontHeight=g2.getFontMetrics().getHeight();
               int fontDesent=g2.getFontMetrics().getDescent();

               //leave room for page number
               double pageHeight = pf.getImageableHeight()-fontHeight;
               double pageWidth = pf.getImageableWidth();
               double tableWidth = (double) tableView.getColumnModel().getTotalColumnWidth();
               double scale = 1;
               if (tableWidth >= pageWidth) {
                       scale =  pageWidth / tableWidth;
               }

               double headerHeightOnPage=
                             tableView.getTableHeader().getHeight()*scale;
               double tableWidthOnPage=tableWidth*scale;
               double     oneRowHeight;
                int  numRowsOnAPage;
               if(choice ==4){
                   oneRowHeight=(tableView.getRowHeight()+0.5+
                                            tableView.getRowMargin())*scale;
                   numRowsOnAPage= 30;

                }
                else{
                    oneRowHeight = (tableView.getRowHeight() +
                                           tableView.getRowMargin()) * scale;
                    numRowsOnAPage =
                            (int) ((pageHeight - headerHeightOnPage) /
                                   oneRowHeight);
                }


               double pageHeightForTable=oneRowHeight*numRowsOnAPage;
               int totalNumPages= (int)Math.ceil((
                             (double)tableView.getRowCount())/numRowsOnAPage);
               if(pi>=totalNumPages) {

                   return NO_SUCH_PAGE;
               }

               g2.translate(pf.getImageableX(),
                              pf.getImageableY());
               g2.drawString("Page: "+(pi+1),(int)pageWidth/2-35,
                             (int)(pageHeight+fontHeight-fontDesent));//bottom center

               g2.translate(0f,headerHeightOnPage);
               g2.translate(0f,-pi*pageHeightForTable);

               //If this piece of the table is smaller than the size available,
               //clip to the appropriate bounds.
               if (pi + 1 == totalNumPages) {
                            int lastRowPrinted = numRowsOnAPage * pi;
                            int numRowsLeft = tableView.getRowCount() - lastRowPrinted;
                            g2.setClip(0, (int)(pageHeightForTable * pi),
                              (int) Math.ceil(tableWidthOnPage),
                              (int) Math.ceil(oneRowHeight * numRowsLeft));
               }
               //else clip to the entire area available.
               else{
                            g2.setClip(0, (int)(pageHeightForTable*pi),
                            (int) Math.ceil(tableWidthOnPage),
                            (int) Math.ceil(pageHeightForTable));
               }

               g2.scale(scale,scale);
               tableView.paint(g2);
               g2.scale(1/scale,1/scale);
               g2.translate(0f,pi*pageHeightForTable);
               g2.translate(0f, -headerHeightOnPage);
               g2.setClip(0, 0,(int) Math.ceil(tableWidthOnPage),
                                      (int)Math.ceil(headerHeightOnPage));
               g2.scale(scale,scale);
               tableView.getTableHeader().paint(g2);//paint header at top




           return Printable.PAGE_EXISTS;
       }


}
