package custsupport;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.io.*;


public class softdesc extends JFrame{



    private JLabel label;

    private JPanel entryPanel;
    private JScrollPane tablePanel;
    private JButton go_button,print_button;

    final  String columnNames[] = { "Code","Name","Version","Start up","End up","Paied","Amount"} ;
    private String pData[][] = new String[0][0];
    private JTable table;
    private JComboBox softCombo;

    private Connection con;
    private Statement state;
    private String software="<none>";
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";


    public softdesc(Connection c) {
        super("Software Information");
      setSize(800,650);
      setLocation(300,80);
      setResizable(false);
      this.setAlwaysOnTop(true);
      con = c;
      //setIconImage(new ImageIcon("images/setting.png").getImage());
      label = new JLabel("Software");
      print_button = new JButton("Print");
      softCombo = new JComboBox();
      softCombo.addItem("<none>");
      go_button = new JButton("Go");
      print_button = new JButton("Print");
      entryPanel = new JPanel();
      System.out.println("Step 0");
      collectSoftware();
      System.out.println("Step 1");
      entryPanel.setPreferredSize(new Dimension(800,80));
      entryPanel.add(label);
      entryPanel.add(softCombo);

      entryPanel.add(go_button);

      entryPanel.add(print_button);
      table = new JTable(pData, columnNames );
      int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
      int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
      tablePanel = new JScrollPane(table,v,h);
      // this.setLayout(new GridLayout(3,1));

      tablePanel.setPreferredSize(new Dimension(750,420));

      getContentPane().add(entryPanel,BorderLayout.NORTH);

      getContentPane().add(tablePanel,BorderLayout.CENTER);



              softCombo.addItemListener(new ItemListener(){
             public void itemStateChanged(ItemEvent e){
                 software = softCombo.getSelectedItem().toString().toUpperCase();
                 //loadDateSort();
             }
 });


              print_button.addActionListener(new ActionListener() {
                           public void actionPerformed(ActionEvent e)
                           {

                               table.setGridColor(Color.black);
                               //table.setBorder(new AbstractAction());
                               table.setAutoResizeMode(1);
                               table.setShowGrid(true);
                               table.setShowHorizontalLines(true);
                               table.setShowVerticalLines(true);
                               printbalance pbalance = new printbalance(1,software,table);
                               pbalance.print();

                               }});



              go_button.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e)
                  {
                      collectData();
                      showAdd();



                  }
              });


    }

    private void collectSoftware(){


    String query =" ";
    String res = " ";
    int found = 0;
    try{
         state = con.createStatement();
        query = "SELECT NAME FROM SOFTWARE";
        ResultSet result = state.executeQuery(query);
        while (result.next()) {

             res = result.getString("NAME").toUpperCase();
             found = 0;

            for(int i = 0;i< softCombo.getItemCount();i++){
                if (res.compareTo(softCombo.getItemAt(i).toString()) == 0)
                   found =1;
            }
            if(found ==0)  softCombo.addItem(res);
        }

    }
                    catch (SQLException ee) {
            System.out.println(ee.toString());
        }

    }


   /* private void collectSoftware(){
        try{

            state = con.createStatement();

            String query = "SELECT * FROM SOFTWARE";
            ResultSet result = state.executeQuery(query);
            while (result.next()) softCombo.addItem(result.getString("NAME").toUpperCase());
        }
        catch(SQLException  ee){System.out.println(ee.toString());}


    }
*/


    private void collectData(){

        int row = getRecNum();
        int i =0;
         pData = new String[row] [7];

         //String date="";
         String query = "";
        // String ord = "";
        // int ordersel = 0;
         try{
//    { "Company","Date","CheckID","Amount"} ;
             state = con.createStatement();

             query ="SELECT * FROM SOFTWARE WHERE NAME ='"+software+"'";

             ResultSet result = state.executeQuery(query);

             while (result.next()){
              //   if(ord.compareTo(result.getString("ORDER").toUpperCase()) ==0) ordersel = 1;
               //  else ordersel = 0;
                 pData[i][0] = result.getString("CODE").toUpperCase();
                 pData[i][1] = result.getString("NAME").toUpperCase();
                 pData[i][2] = Double.toString(result.getDouble("VERSION"));
                 pData[i][3] = result.getString("START").toUpperCase();
                 pData[i][4] = result.getString("END").toUpperCase();
                 pData[i][5] = Double.toString((result.getDouble("PAIED")))+"$";
                 pData[i][6] = Double.toString((result.getDouble("AMOUNT")))+"$";


                 //showAdd();
                i++;
                System.out.println("i= "+i);


             }
            // showAdd();



         }
         catch(SQLException  ee){System.out.println(ee.toString());}

}

private int getRecNum(){
    int num = 0;
    String query="";
    try{

        state = con.createStatement();

            query ="SELECT * FROM SOFTWARE WHERE NAME ='"+software+"'";


       ResultSet result = state.executeQuery(query);
       while (result.next()) num++;
    }
    catch(SQLException  ee){System.out.println(ee.toString());}




    return num;
}

private void showAdd(){
    // collectData();
     /*getContentPane().removeAll();
     table = new JTable(pData, columnNames );
     int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
     int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
     showPanel = new JScrollPane(table,v,h);
     getContentPane().add(entryPanel,BorderLayout.NORTH);
     getContentPane().add(showPanel,BorderLayout.CENTER);
     //                        getContentPane().add(custoPanel);
     getContentPane().add(endPanel,BorderLayout.SOUTH);
*/

        //  collectData();
         getContentPane().removeAll();
          table = new JTable(pData, columnNames );
          int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
          int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
          tablePanel = new JScrollPane(table,v,h);
          entryPanel.setPreferredSize(new Dimension(800,80));
    tablePanel.setPreferredSize(new Dimension(750,420));

    getContentPane().add(entryPanel,BorderLayout.NORTH);

    getContentPane().add(tablePanel,BorderLayout.CENTER);


          show();

//     show();
}


}
