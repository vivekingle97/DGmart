package custsupport;
import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.sql.*;
import java.awt.BorderLayout;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class printbalance extends JFrame implements Printable{

    private String companyname="";
    private JTable tableView;
    private int choice =0;
 /*   private int choice = 0;
    private double cash = 0;
    private double loan = 0;
    private double returned = 0;
    private double total = 0;
  */

    public printbalance(int ch,String company,JTable table) {



        companyname = company;
        tableView = table;
        choice = ch;


    }

    public void print(){


        //print_button.setVisible(false);
       // print_button.setVisible(false);

         PrinterJob printerJob = PrinterJob.getPrinterJob();

        // Get and change default page format settings if necessary.
        PageFormat pageFormat = printerJob.defaultPage();
       pageFormat.setOrientation(PageFormat.PORTRAIT);

        printerJob.setPrintable(printbalance.this);


        printerJob.setJobName("Java Test Printing");



        if (printerJob.printDialog()) {
            try {
                printerJob.print();

            } catch (Exception PrintException) {
                PrintException.printStackTrace();
            }

            printerJob.cancel();


        }

        printerJob.cancel();






    }
    public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {

        if (pi !=0) {
            return Printable.NO_SUCH_PAGE;
        }

        /*
        Graphics2D g2= (Graphics2D) g;


           g2.translate(pf.getImageableX()+5, pf.getImageableY()+5);

           Font  f = new Font("Monospaced",Font.BOLD,12);
           g2.setFont (f);

              g2.drawString("Hello All",30,10);
              g2.drawLine(10,10,300,10);

              paint(g2);
        */
       SimpleDateFormat date = new SimpleDateFormat();
       Graphics2D  g2 = (Graphics2D) g;
               g2.setColor(Color.black);
               g2.translate(pf.getImageableX(), pf.getImageableY());
               Font  f = new Font("Monospaced",Font.BOLD,12);
               g2.setFont (f);
               g2.drawString("COMPUTER SYSTEM",10,10);
               f = new Font("Monospaced",Font.PLAIN,12);
               g2.setFont (f);
               g2.drawString("AKKAR, HALBA Main road",10,25);
               g2.drawString("Tel: 06/691376",10,40);
               g2.drawString("Mobile: 03/426610",10,55);
                g2.drawLine(10,60,480,60);

                   g2.drawString("                STATEMENT OF ACCOUNT ", 10, 80);
                   g2.setFont(new Font("Monospaced", Font.ITALIC, 8));
                   if(choice ==1)
                       g2.drawString("(Supplier)", 210, 90);
                   if(choice ==2)
                       g2.drawString("(Customer)", 210, 90);
                   g2.setFont(f);

                   g2.drawString("DUE FOR: " + companyname, 10, 100);

               //g2.drawLine(11,130,11,250);


//              g2.setColor(Color.BLUE);
//              g2.setFont(new Font("Monospaced",Font.BOLD,12));
 //             g2.drawString("Total: "+finalprice+"$",300,300);
               paint(g2);

               g2.translate(-60,40);
             //  g2.scale(1,1);
               g2.setColor(Color.black);
//               g2.setColor(Color.black);
               int fontHeight=g2.getFontMetrics().getHeight();
               int fontDesent=g2.getFontMetrics().getDescent();

               //leave room for page number
               double pageHeight = pf.getImageableHeight()-fontHeight;
               double pageWidth = pf.getImageableWidth();
               double tableWidth = (double) tableView.getColumnModel().getTotalColumnWidth();
               double scale = 1;
               if (tableWidth >= pageWidth) {
                       scale =  pageWidth / tableWidth;
               }

               double headerHeightOnPage=
                             tableView.getTableHeader().getHeight()*scale;
               double tableWidthOnPage=tableWidth*scale;

               double oneRowHeight=(tableView.getRowHeight()+
                             tableView.getRowMargin())*scale;
               int numRowsOnAPage=
                             (int)((pageHeight-headerHeightOnPage)/oneRowHeight);
               double pageHeightForTable=oneRowHeight*numRowsOnAPage;
               int totalNumPages= (int)Math.ceil((
                             (double)tableView.getRowCount())/numRowsOnAPage);
               if(pi>=totalNumPages) {
                             return NO_SUCH_PAGE;
               }

               g2.translate(pf.getImageableX(),
                              pf.getImageableY());
               g2.drawString("Page: "+(pi+1),(int)pageWidth/2-35,
                             (int)(pageHeight+fontHeight-fontDesent));//bottom center

               g2.translate(0f,headerHeightOnPage);
               g2.translate(0f,-pi*pageHeightForTable);

               //If this piece of the table is smaller than the size available,
               //clip to the appropriate bounds.
               if (pi + 1 == totalNumPages) {
                            int lastRowPrinted = numRowsOnAPage * pi;
                            int numRowsLeft = tableView.getRowCount() - lastRowPrinted;
                            g2.setClip(0, (int)(pageHeightForTable * pi),
                              (int) Math.ceil(tableWidthOnPage),
                              (int) Math.ceil(oneRowHeight * numRowsLeft));
               }
               //else clip to the entire area available.
               else{
                            g2.setClip(0, (int)(pageHeightForTable*pi),
                            (int) Math.ceil(tableWidthOnPage),
                            (int) Math.ceil(pageHeightForTable));
               }

               g2.scale(scale,scale);
               tableView.paint(g2);
               g2.scale(1/scale,1/scale);
               g2.translate(0f,pi*pageHeightForTable);
               g2.translate(0f, -headerHeightOnPage);
               g2.setClip(0, 0,(int) Math.ceil(tableWidthOnPage),
                          (int)Math.ceil(headerHeightOnPage));
               g2.scale(scale,scale);
               g2.setFont(new Font("Monospaced",Font.BOLD,20));
               tableView.getTableHeader().paint(g2);//paint header at top



           return Printable.PAGE_EXISTS;
       }


}
