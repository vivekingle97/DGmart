package custsupport;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.io.*;


public class paycust extends JFrame{
    private JLabel pay_label;
    private JTextField pay_textfield;
    private JButton pay_button, print_button;
    private JPanel entryPanel, buttonPanel;
    private Connection con;
    private Statement state;
    private int id = -1;
    double paid = 0;
    double unpaid = 0;
    double account = 0;
    private String name = "";
    private int receipt = 0;
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";
    private JLabel r_label;
    private JTextField r_textfield;
    private JComboBox codeCombo;
    private JLabel software_label;
    private String code = "";

    public paycust(String last,String first,int ident,Connection c) {

        super(last + " "+first + " Paying");
        name = first +" " + last;
        setSize(270,150);
        setLocation(400,0);
        setResizable(false);
         this.setAlwaysOnTop(true);
        con = c;
        id = ident;
        setIconImage(new ImageIcon("images/newexpense.png").getImage());
      //  addFrame();
       // loadFrameChecker();
       codeCombo = new JComboBox();
       codeCombo.addItem("<none>");
       software_label = new JLabel("Software");

       collectSoftware();
        entryPanel = new JPanel();
        buttonPanel = new JPanel();
         entryPanel.setLayout(new GridLayout(3,2,10,5));
        r_label = new JLabel("Receipt");
        r_textfield = new JTextField(10);
        pay_label = new JLabel("Amount($)");
        pay_textfield = new JTextField(7);
        pay_textfield.setText("0");

        pay_button = new JButton("Pay");
        print_button = new JButton("Print");
        print_button.setVisible(false);
        buttonPanel.add(pay_button);
        buttonPanel.add(print_button);
        entryPanel.add(r_label);
        entryPanel.add(r_textfield);
        entryPanel.add(pay_label);
        entryPanel.add(pay_textfield);
        entryPanel.add(software_label);
        entryPanel.add(codeCombo);

        getContentPane().add(entryPanel,BorderLayout.NORTH);
        getContentPane().add(buttonPanel,BorderLayout.CENTER);

        codeCombo.addItemListener(new ItemListener(){
            public void itemStateChanged(ItemEvent e) {
                code = codeCombo.getSelectedItem().toString().toUpperCase();
                //loadDateSort();
            }
         });

        pay_button.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent e)
              {
                  if(pay()==false)  {

                      print_button.setVisible(true);
                  }
              }
          });
        print_button.addActionListener(new ActionListener() {
                      public void actionPerformed(ActionEvent e)
                      {
                          printbill pbill = new printbill(id,3,name,new JTable(),Double.parseDouble(pay_textfield.getText()),receipt);
                          pbill.print();
                      }
                  });


    }
     private void collectSoftware(){
       try{

           state = con.createStatement();

           String query = "SELECT CODE FROM CUSTDETAILS WHERE IDENTITY = "+id+"";
           ResultSet result = state.executeQuery(query);
           while (result.next()) codeCombo.addItem(result.getString("CODE").toUpperCase());
       }
       catch(SQLException  ee){System.out.println(ee.toString());}


   }



    private boolean pay(){

        paid = Double.parseDouble(pay_textfield.getText());
        unpaid = 0;
        account = 0;
        String query ="";
        receipt = Integer.parseInt(r_textfield.getText());
        boolean found = false;

        SimpleDateFormat date =  new SimpleDateFormat();
        System.out.println("id: " +id);
        try{

            state = con.createStatement();
            query = "SELECT PAIED,ACCOUNT FROM CUSTOMERS WHERE IDENTITY = " +
                    id + "";
            ResultSet result = state.executeQuery(query);
            result.next();
            paid = paid + result.getDouble("PAIED");
            account = result.getDouble("ACCOUNT");
            unpaid = account - paid;
            System.out.println("paid: " + paid + "unpaid: " + unpaid +
                               "account: " + account);

             query = "SELECT SN FROM CUSTPAYMENT";
            ResultSet result1 = state.executeQuery(query);
            while (result1.next()) {

                if (result1.getInt("SN") == receipt)
                    found = true;
            }

            if (found == false) {

                query = "INSERT INTO CUSTPAYMENT VALUES(" + id + "," +
                        Double.parseDouble(pay_textfield.getText()) + ",'" +
                        date.format(new Date()) + "'," + receipt + ",'"+code+"')";
                state.execute(query);
                update();
            }
        }
        catch(SQLException  ee){System.out.println(ee.toString());}
return found;
    }

    private void update(){

        SimpleDateFormat date = new SimpleDateFormat();
        try{

                    state = con.createStatement();

                    String query = "UPDATE CUSTOMERS SET PAIED ="+paid+" , UNPAIED = "+unpaid+" ,LPAYMENT = '"+date.format(new Date())+"' WHERE IDENTITY = "+id+"";
                    state.executeUpdate(query);
                     query = "UPDATE SOFTWARE SET PAIED = PAIED + "+paid+" WHERE CODE = '"+code+"' ";
                    state.executeUpdate(query);

                }
                catch(SQLException  ee){System.out.println(ee.toString());}


    }


}
