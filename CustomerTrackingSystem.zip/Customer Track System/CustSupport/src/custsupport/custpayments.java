package custsupport;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.io.*;

public class custpayments extends JFrame{

    private JScrollPane custoPanel;
    final  String columnNames[] = { "Date","Code","Amount","Receipt"} ;
    private String pData[][];
    private JTable table;
    private Connection con;
    private Statement state;
    private int id=0;
    private String first_name ="";
    private String last_name ="";
    private JButton print_button;
    private int service = 0;
    private JPanel buttonPanel;
    private String paid ="";
    private String unpaid ="";
    private String account ="";
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";

    public custpayments(Connection connection,String lname, String fname,int identity,String p,String up,String acc) {
        super(lname+ " " +fname + " Payments");
        setSize(600,400);
        setLocation(180,80);
        setResizable(false);
         this.setAlwaysOnTop(true);
        con = connection;
        id = identity;
        first_name = fname;
        last_name = lname;
        paid = p;
        unpaid = up;
        account = acc;
        setIconImage(new ImageIcon("images/select_Hover.png").getImage());
       // addFrame();
       // loadFrameChecker();
        buttonPanel = new JPanel();
        collectData();
        table = new JTable(pData, columnNames );
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        custoPanel = new JScrollPane(table,v,h);
        print_button = new JButton("Print", new ImageIcon("images/prints.png"));
        buttonPanel.add(print_button);

        getContentPane().add(custoPanel);
        getContentPane().add(buttonPanel,BorderLayout.SOUTH);



        print_button.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e)
                   {
                       table.setAlignmentX(0);
                       table.setAlignmentY(0);
                       table.setGridColor(Color.black);

                       table.setAutoResizeMode(1);
                       table.setShowGrid(true);
                       table.setShowHorizontalLines(true);
                       table.setShowVerticalLines(true);
                       printchecks ppayment = new printchecks(1,first_name+" "+last_name,table,paid,unpaid,account);
                       ppayment.print();

                   }
        });

addMenu();
    }
    private void collectData(){

       // int row = getRecNum();
        int i =0;
        //        int row = 0;
        setLength();

         try{

             state = con.createStatement();

             String query = "SELECT PAIED,DATE,SN,CODE FROM CUSTPAYMENT WHERE ID = "+id+"";
             ResultSet result = state.executeQuery(query);
             while (result.next()){

                 pData[i][0] = result.getString("DATE");
                 pData[i][1] = result.getString("CODE");
                 pData[i][2] = Double.toString(result.getDouble("PAIED"))+"$";
                 pData[i][3] = Integer.toString(result.getInt("SN"));

                i++;

             }



         }
         catch(SQLException  ee){System.out.println(ee.toString());}


    }

    private void setLength(){

        int row = 0;
        try{

            state = con.createStatement();

            String query = "SELECT * FROM CUSTPAYMENT WHERE ID = "+id+"";
            ResultSet result1 = state.executeQuery(query);
            while(result1.next()) row++;
//            row = result1.getInt("CUSTODETAILS");

            pData = new String[row] [4];





        }
        catch(SQLException  ee){System.out.println(ee.toString());}



    }

    private void addMenu() {
        JMenuBar mbar = new JMenuBar();
        JMenu menu = new JMenu("File");
        JMenuItem reset_user = new JMenuItem("Reset");


        reset_user.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                resetCust();

            }
        });




        menu.add(reset_user);
        mbar.add(menu);
        setJMenuBar(mbar);
    }

    private void resetCust(){

        try{

            state = con.createStatement();

            String query = "UPDATE CUSTOMERS SET PAIED = "+0+", UNPAIED = "+0+" ,ACCOUNT ="+0+" WHERE IDENTITY = "+id+"";
            state.executeUpdate(query);
            query = "DELETE FROM CUSTPAYMENT WHERE ID = "+id+"";
            state.executeUpdate(query);
            showAdd();
        }
        catch(SQLException  ee){System.out.println(ee.toString());}



    }
    private void showAdd(){
        collectData();
        getContentPane().removeAll();
        table = new JTable(pData, columnNames );
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        custoPanel = new JScrollPane(table,v,h);
       // print_button.setVisible(false);
        getContentPane().add(custoPanel);
        getContentPane().add(buttonPanel,BorderLayout.SOUTH);


        show();
    }
    private int getFrameNum(){
        String line ="";
        try{


         FileReader fr = new FileReader("init.pop");
         BufferedReader inFile = new BufferedReader(fr);

         line = inFile.readLine();



     }
   catch(IOException exception){System.out.println("error in init class");}
   return Integer.parseInt(line);
    }

    protected void loadFrameChecker()
    {
    try
       {
            if(getFrameNum() >4){
                int reply = JOptionPane.showConfirmDialog(this,
                        "Too many Frames opened",
                        sMSGBOX_TITLE, JOptionPane.WARNING_MESSAGE);
            }
            }

            catch(Exception e)
            {}

    }

    private void addFrame(){
         int num =0;
         try {



             File file = new File("init.pop");
             FileReader fr = new FileReader(file);
             BufferedReader inFile = new BufferedReader(fr);
             String line = inFile.readLine();
             num = Integer.parseInt(line);
             inFile.close();
             num++;
             File file1 = new File("init.pop");
             PrintWriter pw1 = new PrintWriter(new FileWriter(file1, false));
             pw1.println(num);
             pw1.close();
                 } catch (IOException exception) {System.out.println(exception.toString());}





      }

}
