package custsupport;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.io.*;

public class showdelcust extends JFrame{

    private JScrollPane custoPanel;
    final  String columnNames[] = { "IDENTITY","NAME","PAID","UNPAID","ACCOUNT"} ;
    private String pData[][];
    private JTable table;
    private Connection con;
    private Statement state;
    private int id=0;
    private String first_name ="";
    private String last_name ="";
    private JButton empty_button;
   // private JButton print_button;
    private int service = 0;
    private JPanel buttonPanel;
    private String sMSGBOX_TITLE = "Customer Support V. 1.0";


    public showdelcust(Connection connection) {
        super("Deleted Customers");
        setSize(600,400);
        setLocation(180,80);
        setResizable(false);
         this.setAlwaysOnTop(true);
        con = connection;
        setIconImage(new ImageIcon("images/setting.png").getImage());
    //    addFrame();
     //   loadFrameChecker();
        buttonPanel = new JPanel();
        collectData();
        table = new JTable(pData, columnNames );
        int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
        int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
        custoPanel = new JScrollPane(table,v,h);
        empty_button = new JButton("Empty");
        buttonPanel.add(empty_button);
      //  print_button = new JButton("Print");
      //  buttonPanel.add(print_button);

        getContentPane().add(custoPanel);
        getContentPane().add(buttonPanel,BorderLayout.SOUTH);



      /*  print_button.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e)
                   {
                       table.setAlignmentX(0);
                       table.setAlignmentY(0);
                       table.setGridColor(Color.black);

                       table.setAutoResizeMode(1);
                       table.setShowGrid(true);
                       table.setShowHorizontalLines(true);
                       table.setShowVerticalLines(true);
                       printchecks ppayment = new printchecks(1,first_name+" "+last_name,table);
                       ppayment.print();

                   }
        });

*/

      empty_button.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e)
          {
              emptyRecycle();
              showAdd();

          }
      });

    }
    private void collectData(){

       // int row = getRecNum();
        int i =0;
        //        int row = 0;
        setLength();

         try{

             state = con.createStatement();

             String query = "SELECT * FROM DELETECUSTOMERS";
             ResultSet result = state.executeQuery(query);
             while (result.next()){

                 pData[i][0] = Integer.toString(result.getInt("IDENTITY"));
                 pData[i][1] = result.getString("LNAME") + " " + result.getString("FNAME");
                 pData[i][2] = Double.toString(result.getDouble("PAIED"));
                 pData[i][3] = Double.toString(result.getDouble("UNPAIED"));
                 pData[i][4] = Double.toString(result.getDouble("ACCOUNT"));


                i++;

             }



         }
         catch(SQLException  ee){System.out.println(ee.toString());}


    }

    private void setLength(){

        int row = 0;
        try{

            state = con.createStatement();

            String query = "SELECT * FROM DELETECUSTOMERS";
            ResultSet result1 = state.executeQuery(query);
            while(result1.next()) row++;
//            row = result1.getInt("CUSTODETAILS");

            pData = new String[row] [5];





        }
        catch(SQLException  ee){System.out.println(ee.toString());}



    }

    private void emptyRecycle(){

        try{

                    state = con.createStatement();

                    String query = "DELETE FROM DELETECUSTOMERS";
                    state.executeUpdate(query);

                }
                catch(SQLException  ee){System.out.println(ee.toString());}


    }

    private void showAdd(){
         collectData();
         getContentPane().removeAll();
         table = new JTable(pData, columnNames );
         int v = ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
         int h = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
         custoPanel = new JScrollPane(table,v,h);
         getContentPane().add(custoPanel);
         getContentPane().add(buttonPanel,BorderLayout.SOUTH);

         show();
    }

    private int getFrameNum(){
        String line ="";
        try{


         FileReader fr = new FileReader("init.pop");
         BufferedReader inFile = new BufferedReader(fr);

         line = inFile.readLine();



     }
   catch(IOException exception){System.out.println("error in init class");}
   return Integer.parseInt(line);
    }

    protected void loadFrameChecker()
    {
    try
       {
            if(getFrameNum() >4){
                int reply = JOptionPane.showConfirmDialog(this,
                        "Too many Frames opened",
                        sMSGBOX_TITLE, JOptionPane.WARNING_MESSAGE);
            }
            }

            catch(Exception e)
            {}

    }
    private void addFrame(){
         int num =0;
         try {



             File file = new File("init.pop");
             FileReader fr = new FileReader(file);
             BufferedReader inFile = new BufferedReader(fr);
             String line = inFile.readLine();
             num = Integer.parseInt(line);
             inFile.close();
             num++;
             File file1 = new File("init.pop");
             PrintWriter pw1 = new PrintWriter(new FileWriter(file1, false));
             pw1.println(num);
             pw1.close();
                 } catch (IOException exception) {System.out.println(exception.toString());}





      }


}
