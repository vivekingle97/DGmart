package custsupport;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import java.awt.BorderLayout;
import java.io.*;


public class sellcust  extends JFrame{


    private JLabel label,amount_label,date_label;
    private JTextField amount_textfield,date_textfield;
    private JPanel entryPanel,entryPanel2,entryPanel3,entryPanel4;
   private JButton go_button,cancel_button;
   private Connection con;
  private Statement state;

  private String sMSGBOX_TITLE = "Customer Support V. 1.0";
  private JComboBox softCombo;
  private int ident = 0;
  private String company = "";


    public sellcust(Connection c, int id,String name,String comp){
        super("Selling Systems for "+name);
      setSize(500,450);
      setLocation(300,80);
      setResizable(false);
      this.setAlwaysOnTop(true);
      con = c;
      ident = id;
      company = comp;
      //setIconImage(new ImageIcon("images/setting.png").getImage());
      entryPanel = new JPanel();
      entryPanel2 = new JPanel();
      entryPanel3 = new JPanel();
      entryPanel4 = new JPanel();

      label = new JLabel("Software");
      amount_label = new JLabel("Amount");
      amount_textfield = new JTextField(10);
      date_label = new JLabel("Date");
      date_textfield = new JTextField(10);
      //print_button = new JButton("Print");
      softCombo = new JComboBox();
      softCombo.addItem("<none>");
      collectSoftware();
      go_button = new JButton("Sell");
      cancel_button = new JButton("Cancel");
      entryPanel.add(label);
      entryPanel.add(softCombo);
      entryPanel2.add(amount_label);
      entryPanel2.add(amount_textfield);
      entryPanel3.add(date_label);
      entryPanel3.add(date_textfield);
      entryPanel4.add(go_button);
      entryPanel4.add(cancel_button);

    getContentPane().setLayout(new GridLayout(4,1));
      getContentPane().add(entryPanel);
      getContentPane().add(entryPanel2);
      getContentPane().add(entryPanel3);
      getContentPane().add(entryPanel4);

      go_button.addActionListener(new ActionListener() {
              public void actionPerformed(ActionEvent e)
              {
                  if (amount_textfield.getText().compareTo("") !=0 && date_textfield.getText().compareTo("") !=0){

                      sellCust();
                  }

              }
          });

      cancel_button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
          setVisible(false);
      }
  });

    }

    private void collectSoftware(){
    try{

        state = con.createStatement();

        String query = "SELECT * FROM SOFTWARE";
        ResultSet result = state.executeQuery(query);
        while (result.next()) softCombo.addItem(result.getString("CODE").toUpperCase());
    }
    catch(SQLException  ee){System.out.println(ee.toString());}


}
private void sellCust(){

     String query = "";
     try{
         state = con.createStatement();

             query = "INSERT INTO CUSTDETAILS VALUES(" + ident + ",'"+softCombo.getSelectedItem().toString()+"','" + date_textfield.getText() +
                     "','" + company +
                     "'," +
                     Double.parseDouble(amount_textfield.getText()) + ")";
             state.execute(query);
             updateCust();
             amount_textfield.setText("sold");
             date_textfield.setText("sold");
     }
     catch(SQLException  ee){System.out.println(ee.toString());}






    }
    private void updateCust(){

        double unpaid =0,account_=0;
        try{

            state = con.createStatement();

            String query = "SELECT  UNPAIED,ACCOUNT FROM CUSTOMERS WHERE IDENTITY = "+ident+"";
            ResultSet result1 = state.executeQuery(query);
            if (result1.next()){
                //paid = result1.getDouble("PAIED");
                unpaid = result1.getDouble("UNPAIED");
                account_ = result1.getDouble("ACCOUNT");
            }
            account_ = account_ + Double.parseDouble(amount_textfield.getText());
            unpaid = unpaid + Double.parseDouble(amount_textfield.getText());

             query = "UPDATE CUSTOMERS SET ACCOUNT = "+account_+" , UNPAIED = "+unpaid+" WHERE IDENTITY = "+ident+"";
             state.executeUpdate(query);
        }

        catch(SQLException  ee){System.out.println(ee.toString());}



    }

}
